<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["judul"])) {
    $judul = $_POST["judul"];
    $deskripsi = $_POST["deskripsi"];
    $tanggal = $_POST["tanggal"];

    if ($_FILES["foto"]["name"]) {
        $foto = $_FILES["foto"]["name"];
        $tmp_name = $_FILES["foto"]["tmp_name"];
        $target_dir = "uploads/kegiatan/";

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        move_uploaded_file($tmp_name, $target_dir . $foto);
    } else {
        $foto = NULL;
    }

    $query = "INSERT INTO kegiatan (judul, deskripsi, tanggal, foto) VALUES ('$judul', '$deskripsi', '$tanggal', '$foto')";
    mysqli_query($conn, $query);

    header("Location: kegiatan.php");
    exit();
}

if (isset($_POST["hapus_id"])) {
    $hapus_id = $_POST["hapus_id"];

    $foto_q = mysqli_query($conn, "SELECT foto FROM kegiatan WHERE id_kegiatan = $hapus_id");
    $foto_row = mysqli_fetch_assoc($foto_q);
    if ($foto_row && $foto_row["foto"]) {
        $file_path = "uploads/kegiatan/" . $foto_row["foto"];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    mysqli_query($conn, "DELETE FROM kegiatan WHERE id_kegiatan = $hapus_id");
    header("Location: kegiatan.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kegiatan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
        }
        h2 {
            text-align: center;
            color: #2C3E50;
        }
        form {
            margin-bottom: 20px;
            padding: 15px;
            background: #ecf0f1;
            border-radius: 8px;
        }
        label {
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #1ABC9C;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #16A085;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #34495E;
            color: white;
        }
        td img {
            width: 100px;
            border-radius: 5px;
        }
        .hapus-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .hapus-btn:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manajemen Kegiatan</h2>

    <form action="kegiatan.php" method="post" enctype="multipart/form-data">
        <label>Judul Kegiatan:</label>
        <input type="text" name="judul" required>

        <label>Deskripsi:</label>
        <textarea name="deskripsi" required></textarea>

        <label>Tanggal:</label>
        <input type="date" name="tanggal" required>

        <label>Foto Kegiatan:</label>
        <input type="file" name="foto" accept="image/*">

        <button type="submit">Tambah Kegiatan</button>
    </form>

    <table>
        <tr>
            <th>Foto</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>

        <?php
        $result = mysqli_query($conn, "SELECT * FROM kegiatan ORDER BY tanggal DESC");

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>";
            if ($row['foto']) {
                echo "<img src='uploads/kegiatan/" . $row['foto'] . "' alt='Foto Kegiatan'>";
            } else {
                echo "Tidak ada foto";
            }
            echo "</td>";
            echo "<td>" . htmlspecialchars($row['judul']) . "</td>";
            echo "<td>" . htmlspecialchars($row['deskripsi']) . "</td>";
            echo "<td>" . $row['tanggal'] . "</td>";
            echo "<td>
                    <form method='post' onsubmit=\"return confirm('Yakin ingin menghapus kegiatan ini?');\">
                        <input type='hidden' name='hapus_id' value='" . $row['id_kegiatan'] . "'>
                        <button type='submit' class='hapus-btn'>Hapus</button>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>

    <div style="text-align: center; margin-top: 20px;">
        <a href="dashboard.php" style="
            display: inline-block;
            background: #3498DB;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        ">Kembali ke Dashboard</a>
    </div>
</div>

</body>
</html>

