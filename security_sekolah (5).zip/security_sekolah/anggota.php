<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit_anggota"])) {
    $nama_anggota = $_POST["nama_anggota"];
    $jabatan = $_POST["jabatan"];
    $foto_anggota = $_FILES["foto_anggota"]["name"];
    $foto_anggota = time() . '_' . basename($foto_anggota);
    $target_file_anggota = "uploads/" . $foto_anggota;
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];

    if (in_array($_FILES["foto_anggota"]["type"], $allowed_types)) {
        if (move_uploaded_file($_FILES["foto_anggota"]["tmp_name"], $target_file_anggota)) {
            $stmt = $conn->prepare("INSERT INTO anggota (nama, jabatan, foto) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nama_anggota, $jabatan, $foto_anggota);
            $stmt->execute();
        } else {
            echo "<script>alert('Gagal upload foto anggota');</script>";
        }
    } else {
        echo "<script>alert('Format foto anggota tidak valid');</script>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus_id"])) {
    $hapus_id = $_POST["hapus_id"];

    $foto_query = mysqli_query($conn, "SELECT foto FROM anggota WHERE id = $hapus_id");
    $foto_row = mysqli_fetch_assoc($foto_query);
    if ($foto_row && $foto_row["foto"]) {
        $file_path = "uploads/" . $foto_row["foto"];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    mysqli_query($conn, "DELETE FROM anggota WHERE id = $hapus_id");
    header("Location: anggota.php");
    exit();
}

$result_anggota = mysqli_query($conn, "SELECT * FROM anggota");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background: white;
            padding: 20px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-top: 40px;
        }
        input {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #1ABC9C;
            color: white;
            padding: 10px;
            width: 10%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #16A085;
        }
        .hapus-btn {
            background: #e74c3c;
            color: white;
            padding: 10px 60px;
            border: none;
            width: 50%;
            border-radius: 5px;
            cursor: pointer;
        }
        .hapus-btn:hover {
            background: #c0392b;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #2C3E50;
            color: white;
        }
        img {
            width: 50px;
            height: 50px;
            border-radius: 5px;
        }
        .back-link {
            text-align: center;
            margin-top: 30px;
        }
        .back-link a {
            display: inline-block;
            background: #3498DB;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tambah Anggota</h2>
        <form action="anggota.php" method="POST" enctype="multipart/form-data">

            <label>Nama</label>
            <input type="text" name="nama_anggota" required>

            <label>Jabatan</label>
            <input type="text" name="jabatan" required>

            <label>Foto</label>
            <input type="file" name="foto_anggota" required>

            <button type="submit" name="submit_anggota">Tambah</button>
        </form>

        <h2>Data Anggota</h2>
        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($result_anggota)) { ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['nama']); ?></td>
                <td><?= htmlspecialchars($row['jabatan']); ?></td>
                <td><img src="uploads/<?= htmlspecialchars($row['foto']); ?>" alt="Foto Anggota"></td>
                <td>
                    <form method="post" onsubmit="return confirm('Yakin ingin menghapus anggota ini?');">
                        <input type="hidden" name="hapus_id" value="<?= $row['id']; ?>">
                        <button type="submit" class="hapus-btn">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>

        <div class="back-link">
            <a href="dashboard.php">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>
