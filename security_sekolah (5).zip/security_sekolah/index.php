<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff; /* Background putih */
            color: black;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }

        .login-container {
            background: rgb(240, 240, 240);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        .login-container h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }

        .input-group {
            text-align: left;
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        .input-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #aaa;
            background: #fff;
            border-radius: 5px;
            font-size: 14px;
            color: black;
        }

        .input-group input:focus {
            outline: none;
            border-color: #555;
        }

        .error {
            color: #ff4d4d;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .login-btn {
            background: #2C3E50; 
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            font-size: 18px;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-btn:hover {
            background: #777;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>LOGIN</h2>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>

        <form action="login.php" method="post">
            <div class="input-group">
                <label>Username</label>
                <input type="text" name="uname" placeholder="Masukkan username">
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Masukkan password">
            </div>

            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>

</body>
</html>
