<?php
session_start();
include "koneksi.php";

// Cek apakah user sudah login
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

// Proses Tambah Data Tamu
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $tujuan = $_POST["tujuan"];
    $waktu = $_POST["waktu"];

    // Cek apakah ada file foto yang diunggah
    if ($_FILES["foto"]["name"]) {
        $foto = $_FILES["foto"]["name"];
        $tmp_name = $_FILES["foto"]["tmp_name"];
        $target_dir = "uploads/tamu/";

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        move_uploaded_file($tmp_name, $target_dir . $foto);
    } else {
        $foto = NULL;
    }

    $query = "INSERT INTO tamu (nama, tujuan, waktu, foto) VALUES ('$nama', '$tujuan', '$waktu', '$foto')";
    mysqli_query($conn, $query);

    header("Location: tamu.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Tamu</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
        .container { width: 80%; margin: auto; padding: 20px; background: white; box-shadow: 0px 4px 8px rgba(0,0,0,0.1); border-radius: 8px; margin-top: 20px; }
        h2 { text-align: center; color: #2C3E50; }
        form { margin-bottom: 20px; padding: 15px; background: #ecf0f1; border-radius: 8px; }
        label { font-weight: bold; }
        input, textarea { width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ccc; border-radius: 5px; }
        button { background: #1ABC9C; color: white; padding: 10px; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #16A085; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: white; }
        table, th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background: #34495E; color: white; }
        td img { width: 100px; border-radius: 5px; }
        .delete-btn { color: white; background-color: red; padding: 5px 10px; border-radius: 5px; text-decoration: none; }
        .delete-btn:hover { background-color: darkred; }
    </style>
</head>
<body>
<br><br><br><br><br>
<div class="container">
    <h2>Daftar Tamu</h2>

    <form action="tamu.php" method="post" enctype="multipart/form-data">
        <label>Nama Tamu:</label>
        <input type="text" name="nama" required>
        <label>Tujuan Kedatangan:</label>
        <textarea name="tujuan" required></textarea>
        <label>Waktu Kunjungan:</label>
        <input type="datetime-local" name="waktu" required>
        <label>Foto Tamu:</label>
        <input type="file" name="foto" accept="image/*">
        <button type="submit">Tambah Tamu</button>
    </form>

    <table>
        <tr>
            <th>Foto</th>
            <th>Nama</th>
            <th>Tujuan</th>
            <th>Waktu Kunjungan</th>
            <th>Aksi</th>
        </tr>

        <?php
        $result = mysqli_query($conn, "SELECT * FROM tamu ORDER BY waktu DESC");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>";
            echo $row['foto'] ? "<img src='uploads/tamu/{$row['foto']}' alt='Foto Tamu'>" : "Tidak ada foto";
            echo "</td>";
            echo "<td>{$row['nama']}</td>";
            echo "<td>{$row['tujuan']}</td>";
            echo "<td>{$row['waktu']}</td>";
            echo "<td><a href='hapus_tamu.php?id={$row['id']}' onclick=\"return confirm('Yakin ingin menghapus?');\" class='delete-btn'>Hapus</a></td>";
            echo "</tr>";
        }
        ?>
    </table>

    <div style="text-align: center; margin-top: 20px;">
        <a href="dashboard.php" style="display: inline-block; background: #3498DB; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Kembali ke Dashboard</a>
    </div>
</div>
</body>
</html>
