
<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

$anggota = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM anggota"))['total'];
$kegiatan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM kegiatan"))['total'];
$tamu = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM tamu"))['total'];
$siswa_keluar = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa_keluar"))['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Security</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background: #f4f4f4;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: #2C3E50;
            color: white;
            padding: 20px;
            position: fixed;
        }
        .sidebar h2 {
            text-align: center;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 20px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            background: #34495E;
            border-radius: 5px;
            text-align: center;
        }
        .sidebar ul li a:hover {
            background: #1ABC9C;
        }
        .content {
            margin-left: 500px;
            padding: 20px;
            width: calc(100% - 270px);
        }
        h1 {
            color: #2C3E50;
        }
        .cards {
            display: flex;
            gap: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 200px;
            text-align: center;
        }
        .card h3 {
            margin: 20;
            color: #333;
        }
        .card p {
            font-size: 24px;
            font-weight: bold;
            color: #1ABC9C;
        }
        .logout {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background: red;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .logout:hover {
            background: darkred;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Security Admin</h2>
        <ul>
            <br>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="anggota.php">Data Anggota</a></li>
            <li><a href="kegiatan.php">Kegiatan</a></li>
            <li><a href="tamu.php">Tamu</a></li>
            <li><a href="siswa_keluar.php">Siswa Keluar</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="content">
        <h1>Selamat Datang</h1>
        <p>Selamat datang di sistem administrasi keamanan sekolah.</p>

        <div class="cards">
            <div class="card">
                <h3>Data Anggota</h3>
                <p><?php echo $anggota; ?></p>
            </div>
            <div class="card">
                <h3>Kegiatan</h3>
                <p><?php echo $kegiatan; ?></p>
            </div>
            <div class="card">
                <h3>Tamu</h3>
                <p><?php echo $tamu; ?></p>
            </div>
            <div class="card">
                <h3>Siswa Keluar</h3>
                <p><?php echo $siswa_keluar; ?></p>
            </div>
        </div>

        <a class="logout" href="logout.php">Logout</a>
    </div>
</body>
</html>
