<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $result = mysqli_query($conn, "SELECT foto FROM tamu WHERE id = $id");
    $data = mysqli_fetch_assoc($result);
    if ($data && $data['foto']) {
        $foto_path = "uploads/tamu/" . $data['foto'];
        if (file_exists($foto_path)) {
            unlink($foto_path);
        }
    }

    mysqli_query($conn, "DELETE FROM tamu WHERE id = $id");
}

header("Location: tamu.php");
exit();
?>
