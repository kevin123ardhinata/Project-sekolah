<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

// Tambah Data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nama'])) {
    $nama = $_POST["nama"];
    $kelas = $_POST["kelas"];
    $alasan = $_POST["alasan"];
    $foto = $_FILES["foto"]["name"];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($foto);

    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
        $query = "INSERT INTO siswa_keluar (nama, kelas, alasan, foto) VALUES ('$nama', '$kelas', '$alasan', '$foto')";
        if (mysqli_query($conn, $query)) {
            header("Location: siswa_keluar.php");
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}

// Hapus Data
if (isset($_GET['hapus_id'])) {
    $id = $_GET['hapus_id'];

    $query = "SELECT foto FROM siswa_keluar WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $foto = $row['foto'];

    if ($foto && file_exists("uploads/" . $foto)) {
        unlink("uploads/" . $foto);
    }

    $delete_query = "DELETE FROM siswa_keluar WHERE id = $id";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: siswa_keluar.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Ambil Data
$result = mysqli_query($conn, "SELECT * FROM siswa_keluar ORDER BY waktu DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa Keluar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background: white;
            padding: 20px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #1ABC9C;
            color: white;
            padding: 10px;
            width: 100px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #16A085;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background: #2C3E50;
            color: white;
        }
        img {
            width: 50px;
            height: 50px;
            border-radius: 5px;
        }
        .hapus-btn {
            background: #e74c3c;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .hapus-btn:hover {
            background: #c0392b;
        }
        .dashboard-link {
            display: inline-block;
            background: #3498DB;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tambah Siswa Keluar</h2>
        <form action="siswa_keluar.php" method="POST" enctype="multipart/form-data">
            <label>Nama</label>
            <input type="text" name="nama" required>
            
            <label>Kelas</label>
            <input type="text" name="kelas" required>

            <label>Alasan</label>
            <textarea name="alasan" required></textarea>

            <label>Foto</label>
            <input type="file" name="foto" required>

            <button type="submit">Tambah</button>
        </form>

        <h2>Data Siswa Keluar</h2>
        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Alasan</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $row['nama']; ?></td>
                <td><?php echo $row['kelas']; ?></td>
                <td><?php echo $row['alasan']; ?></td>
                <td><img src="uploads/<?php echo $row['foto']; ?>" alt="Foto <?php echo $row['nama']; ?>"></td>
                <td>
                    <form method="GET" onsubmit="return confirm('Yakin ingin menghapus data ini?');" style="display:inline;">
                        <input type="hidden" name="hapus_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" class="hapus-btn">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>

        <div style="text-align: center;">
            <a href="dashboard.php" class="dashboard-link">Kembali ke Dashboard</a>
        </div>
    </div>
</body>
</html>
