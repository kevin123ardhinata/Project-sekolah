<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>

body {
    font-family: Arial, sans-serif;
    background-color: #121212; 
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    flex-direction: column;
    text-align: center;
    margin: 0;
}


.container {
    background: #f1e9e9;
    padding: 30px;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
    border-radius: 15px;
    text-align: center;
    width: 350px;
}


h1 {
    font-size: 28px;
    font-weight: bold;
    color: #1DB954; 
    margin-bottom: 20px;
}


.nav-buttons a {
    display: block; 
    width: 100%; 
    padding: 12px;
    font-size: 16px;
    font-weight: bold;
    color: white;
    background-color: #1DB954;
    border-radius: 25px;
    text-decoration: none;
    transition: 0.3s;
    margin: 8px 0; 
    text-align: center;
}

.nav-buttons a:hover {
    background-color: #18a74e;
}       
</style>
</head>


<?php
session_start();

if (isset($_SESSION['id_pengguna']) && isset($_SESSION['username'])) {
?>
<!DOCTYPE html>
<head>
    <title>HOME</title>
</head>
<body>
    <h1>Hello, <?php echo $_SESSION['username']; ?></h1>
    <div class="nav-buttons">
    <a href="logout.php">LOGOUT</a>
</body>
</html>
<?php
} else {
    header("Location: index.php");
    exit();
}
